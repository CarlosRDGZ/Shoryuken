package spark;

@FunctionalInterface
public interface RouteGroup {
    void addRoutes();
}